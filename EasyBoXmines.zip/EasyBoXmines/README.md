# EasyBoXmines

Отдельный плагин для **Paper 1.21.11**. `ServerUtils` не изменяет и не требует его исходников для работы основной механики.

## Основные возможности

- Выделение кубической зоны палкой: ЛКМ = позиция 1, ПКМ = позиция 2.
- Живая подсветка границ частицами.
- GUI-настройка шахты.
- Блоки добавляются из основной руки и настраиваются числом (`10`) или диапазоном (`10-25`).
- Режимы `DROPS` и `COINS`.
- Автоматический reset.
- Голограмма через `TextDisplay`: название, статус, таймер и количество Nom-блоков.
- При каждом reset по умолчанию размещается **7 Nom Coin блоков**. Количество можно задать диапазоном `nom-blocks-min/max`.
- Nom Coin блок визуально оформлен по предоставленному дизайну: `Блок Nom Коинов`, эквивалент 9 монет.
- Пересекающиеся шахты при создании блокируются.
- Данные шахт хранятся в `plugins/EasyBoXmines/mines.yml`.

## Команды

`/mines wand`

`/mines create <название>`

`/mines edit <название>`

`/mines delete <название>`

`/mines list`

`/mines info <название>`

`/mines reset <название>`

`/mines resetall`

`/mines reload`

## Coins

Так как API конкретной системы Coins внутри вашего `ServerUtils` в исходных файлах этого плагина не предоставлен, режим `COINS` использует настраиваемую консольную команду:

`coin-reward-command: 'coins give %player% %amount%'

Замените её на фактическую команду вашей валюты. `ServerUtils.jar` при этом не модифицируется.

## Сборка

Требуется **Java 21** для Paper 1.21.11. Paper указывает Java 21 для диапазона 1.20–1.21.11. Проект использует `paper-api:1.21.11-R0.1-SNAPSHOT`.

Команда:

```bash
gradle clean build --refresh-dependencies
```

Готовый jar появится в `build/libs/EasyBoXmines-1.0.0.jar`.

## Исправления после первой сборки

В этой версии исправлены ошибки компиляции:
- чтение материала палки сделано через `Material.matchMaterial(...)`;
- позиция Nom-блока создаётся через `Pos.of(block.getLocation())`;
- конструктор `Mine` корректно сохраняет обе точки (`pos1` и `pos2`).

## Hologram
The mine hologram now shows the mine name, live remaining block count and reset countdown. `%blocks%` is decremented whenever a block is broken and `%maxblocks%` is the total volume of the selected region.
