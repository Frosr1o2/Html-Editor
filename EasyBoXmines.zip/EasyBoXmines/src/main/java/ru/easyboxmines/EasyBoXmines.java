package ru.easyboxmines;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import ru.easyboxmines.command.MinesCommand;
import ru.easyboxmines.listener.GuiListener;
import ru.easyboxmines.listener.MineListener;
import ru.easyboxmines.listener.SelectionListener;
import ru.easyboxmines.model.Mine;
import ru.easyboxmines.model.MineMode;
import ru.easyboxmines.model.Pos;
import ru.easyboxmines.service.*;
import ru.easyboxmines.util.TextUtil;

public final class EasyBoXmines extends JavaPlugin {
    private SelectionService selections;
    private MineStorage storage;
    private HologramService holograms;
    private MineService mines;
    private GuiService gui;
    private BukkitTask tickTask;
    private BukkitTask selectionTask;
    private ServerUtilsCurrency currency;

    @Override public void onEnable() {
        saveDefaultConfig();
        selections = new SelectionService();
        storage = new MineStorage(this); storage.load();
        holograms = new HologramService(this, storage);
        mines = new MineService(this, storage, holograms);
        gui = new GuiService(this);
        currency = new ServerUtilsCurrency(this);

        var pm = Bukkit.getPluginManager();
        pm.registerEvents(new SelectionListener(this, selections), this);
        pm.registerEvents(new MineListener(this), this);
        pm.registerEvents(new GuiListener(this), this);
        PluginCommand command = getCommand("mines");
        if (command != null) { var executor=new MinesCommand(this); command.setExecutor(executor); command.setTabCompleter(executor); }

        for (Mine m : storage.all()) {
            if (m.nextResetAtMillis() <= 0) m.setNextResetAtMillis(System.currentTimeMillis()+m.resetIntervalSeconds()*1000L);
            holograms.spawnOrUpdate(m);
        }
        tickTask = Bukkit.getScheduler().runTaskTimer(this, mines::tick, 20L, 20L);
        selectionTask = Bukkit.getScheduler().runTaskTimer(this, this::renderSelections, 10L, Math.max(1L,getConfig().getLong("selection.particle-period-ticks",5)));
        getLogger().info("EasyBoXmines enabled for Paper 1.21.11");
    }
    @Override public void onDisable() {
        if(tickTask!=null)tickTask.cancel(); if(selectionTask!=null)selectionTask.cancel();
        if(holograms!=null)holograms.removeAll(); if(storage!=null)storage.save();
    }
    private void renderSelections() {
        Particle particle;
        try { particle=Particle.valueOf(getConfig().getString("selection.particle","END_ROD")); } catch(Exception e){particle=Particle.END_ROD;}
        int edge=Math.max(4,getConfig().getInt("selection.edge-points",80));
        double view=getConfig().getDouble("selection.particle-distance",64);
        for(Player p:Bukkit.getOnlinePlayers()){
            if(!p.hasPermission("easyboxmines.admin"))continue; var s=selections.get(p); if(!s.complete())continue;
            var a=s.pos1();var b=s.pos2();if(a.getWorld()==null||!a.getWorld().equals(b.getWorld()))continue;if(p.getLocation().distanceSquared(a)>view*view && p.getLocation().distanceSquared(b)>view*view)continue;
            double minX=Math.min(a.getBlockX(),b.getBlockX()), maxX=Math.max(a.getBlockX()+1,b.getBlockX()+1);
            double minY=Math.min(a.getBlockY(),b.getBlockY()), maxY=Math.max(a.getBlockY()+1,b.getBlockY()+1);
            double minZ=Math.min(a.getBlockZ(),b.getBlockZ()), maxZ=Math.max(a.getBlockZ()+1,b.getBlockZ()+1);
            // 12 edges, capped so huge selections stay cheap.
            drawEdge(p,particle,minX,minY,minZ,maxX,minY,minZ,edge); drawEdge(p,particle,minX,maxY,minZ,maxX,maxY,minZ,edge);
            drawEdge(p,particle,minX,minY,maxZ,maxX,minY,maxZ,edge); drawEdge(p,particle,minX,maxY,maxZ,maxX,maxY,maxZ,edge);
            drawEdge(p,particle,minX,minY,minZ,minX,maxY,minZ,edge); drawEdge(p,particle,maxX,minY,minZ,maxX,maxY,minZ,edge);
            drawEdge(p,particle,minX,minY,maxZ,minX,maxY,maxZ,edge); drawEdge(p,particle,maxX,minY,maxZ,maxX,maxY,maxZ,edge);
            drawEdge(p,particle,minX,minY,minZ,minX,minY,maxZ,edge); drawEdge(p,particle,maxX,minY,minZ,maxX,minY,maxZ,edge);
            drawEdge(p,particle,minX,maxY,minZ,minX,maxY,maxZ,edge); drawEdge(p,particle,maxX,maxY,minZ,maxX,maxY,maxZ,edge);
            p.sendActionBar(TextUtil.parse("<gradient:#4DFFFF:#198080>EasyBoXmines</gradient> <gray>• <white>Выделение активно"));
        }
    }
    private void drawEdge(Player p,Particle particle,double x1,double y1,double z1,double x2,double y2,double z2,int points){for(int i=0;i<=points;i++){double t=i/(double)points;double x=x1+(x2-x1)*t,y=y1+(y2-y1)*t,z=z1+(z2-z1)*t;p.spawnParticle(particle,x,y,z,1,0,0,0,0);}}

    public ItemStack wand(){
        Material mat = Material.matchMaterial(getConfig().getString("selection.wand-material", "STICK"));
        if (mat == null) mat = Material.STICK; ItemStack item=new ItemStack(mat);ItemMeta meta=item.getItemMeta();meta.displayName(TextUtil.parse("<gradient:#4DFFFF:#198080>EasyBoXmines • Wand</gradient>"));meta.lore(java.util.List.of(TextUtil.parse("<gray>ЛКМ — точка 1"),TextUtil.parse("<gray>ПКМ — точка 2")));item.setItemMeta(meta);return item;
    }
    public void applyDefaults(Mine m){m.setResetIntervalSeconds(getConfig().getInt("mine-defaults.reset-interval-seconds",900));m.setMode(MineMode.parse(getConfig().getString("mine-defaults.mode"),MineMode.DROPS));m.setProtectPlacement(getConfig().getBoolean("mine-defaults.protect-placement",true));m.setNomBlocksMin(getConfig().getInt("mine-defaults.nom-blocks-min",7));m.setNomBlocksMax(getConfig().getInt("mine-defaults.nom-blocks-max",7));m.setNomCoinValue(getConfig().getInt("mine-defaults.nom-block-coin-value",9));m.setHologramEnabled(getConfig().getBoolean("mine-defaults.hologram-enabled",true));m.setHologramOffsetY(getConfig().getDouble("mine-defaults.hologram-offset-y",2.5));m.setCoinRewardCommand(getConfig().getString("mine-defaults.coin-reward-command",""));m.blocks().add(new ru.easyboxmines.model.BlockRule(Material.STONE,10,25));}
    public void saveMine(Mine m){storage.put(m);mines.reset(m,false);}
    public void deleteMine(Mine m){storage.remove(m.id());holograms.remove(m);storage.save();}
    public SelectionService selections(){return selections;} public MineStorage storage(){return storage;} public HologramService holograms(){return holograms;} public MineService mines(){return mines;} public GuiService gui(){return gui;} public ServerUtilsCurrency currency(){return currency;}
}
