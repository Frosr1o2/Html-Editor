package ru.easyboxmines.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import ru.easyboxmines.model.Mine;

public class AnvilHolder implements InventoryHolder {
    public final Mine mine;
    public final String action;
    public final int index;
    public AnvilHolder(Mine mine, String action, int index) { this.mine=mine; this.action=action; this.index=index; }
    @Override public Inventory getInventory() { return null; }
}
