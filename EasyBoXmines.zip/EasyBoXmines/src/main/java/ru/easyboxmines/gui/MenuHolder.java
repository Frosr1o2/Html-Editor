package ru.easyboxmines.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import ru.easyboxmines.model.Mine;

public class MenuHolder implements InventoryHolder {
    public final String type;
    public final Mine mine;
    public MenuHolder(String type, Mine mine) { this.type=type; this.mine=mine; }
    @Override public Inventory getInventory() { return null; }
}
