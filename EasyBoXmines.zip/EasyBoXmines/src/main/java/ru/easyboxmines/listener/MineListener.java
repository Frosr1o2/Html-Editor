package ru.easyboxmines.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import ru.easyboxmines.EasyBoXmines;
import ru.easyboxmines.model.Mine;
import ru.easyboxmines.model.MineMode;
import ru.easyboxmines.util.TextUtil;

public class MineListener implements Listener {
    private final EasyBoXmines plugin;
    public MineListener(EasyBoXmines plugin){this.plugin=plugin;}

    @EventHandler public void breakBlock(BlockBreakEvent e){
        Mine m=plugin.mines().find(e.getBlock().getLocation());
        if(m==null)return;
        e.setDropItems(m.mode()!=MineMode.COINS && !m.isNom(e.getBlock().getLocation()));
        plugin.mines().handleBreak(e.getPlayer(), e.getBlock());
    }

    @EventHandler public void placeBlock(BlockPlaceEvent e){
        Mine m=plugin.mines().find(e.getBlock().getLocation());
        if(m==null||!m.protectPlacement())return;
        e.setCancelled(true); e.getPlayer().sendActionBar(TextUtil.parse("<red>В шахте нельзя ставить блоки</red>"));
    }
}
