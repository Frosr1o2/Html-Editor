package ru.easyboxmines.listener;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.ItemStack;
import ru.easyboxmines.EasyBoXmines;
import ru.easyboxmines.gui.AnvilHolder;
import ru.easyboxmines.gui.MenuHolder;
import ru.easyboxmines.model.BlockRule;
import ru.easyboxmines.model.Mine;
import ru.easyboxmines.model.MineMode;
import ru.easyboxmines.util.TextUtil;

import java.util.Locale;

public class GuiListener implements Listener {
    private final EasyBoXmines plugin;
    public GuiListener(EasyBoXmines plugin) { this.plugin=plugin; }
    @EventHandler public void drag(InventoryDragEvent e) { if (e.getView().getTopInventory().getHolder() instanceof MenuHolder) e.setCancelled(true); }
    @EventHandler public void click(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getView().getTopInventory().getHolder() instanceof MenuHolder h) {
            e.setCancelled(true); if (e.getClickedInventory()!=e.getView().getTopInventory()) return;
            Mine m=h.mine; int s=e.getRawSlot();
            if (s==4) plugin.gui().openRangeAnvil(p,m,"NAME",-1,m.name());
            else if (s==10) {
                ItemStack hand=p.getInventory().getItemInMainHand();
                if (hand.getType().isAir() || !hand.getType().isBlock()) { p.sendMessage(TextUtil.parse("<red>Возьми блок в основную руку.")); return; }
                int idx=m.blocks().size(); m.blocks().add(new BlockRule(hand.getType(),10,25)); plugin.gui().openRangeAnvil(p,m,"BLOCK",idx,"10-25");
            } else if (s==12) { m.setMode(m.mode()==MineMode.DROPS?MineMode.COINS:MineMode.DROPS); plugin.gui().openEditor(p,m); }
            else if (s==14) plugin.gui().openRangeAnvil(p,m,"INTERVAL",-1,String.valueOf(m.resetIntervalSeconds()));
            else if (s==16) plugin.gui().openRangeAnvil(p,m,"NOM",-1,m.nomBlocksMin()+"-"+m.nomBlocksMax());
            else if (s>=27 && s<45) { int idx=s-27; if(idx<m.blocks().size()) { if(e.isRightClick()){m.blocks().remove(idx); plugin.gui().openEditor(p,m);} else plugin.gui().openRangeAnvil(p,m,"BLOCK",idx,m.blocks().get(idx).min()+"-"+m.blocks().get(idx).max()); } }
            else if (s==45) p.closeInventory();
            else if (s==49) { plugin.saveMine(m); p.closeInventory(); p.sendMessage(TextUtil.parse("<green>✔ Шахта «"+m.name()+"» сохранена и обновлена.")); }
            else if (s==53) { plugin.deleteMine(m); p.closeInventory(); p.sendMessage(TextUtil.parse("<yellow>Шахта удалена.")); }
        }
        if (e.getView().getTopInventory().getHolder() instanceof AnvilHolder holder) {
            int raw=e.getRawSlot();
            if(raw==2) {
                AnvilInventory anvil = (AnvilInventory) e.getView().getTopInventory();
                String text = anvil.getRenameText();
                if (text == null || text.isBlank()) {
                    ItemStack left = anvil.getItem(0);
                    if (left != null && left.hasItemMeta() && left.getItemMeta().hasDisplayName()) {
                        text = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(left.getItemMeta().displayName());
                    } else text = "";
                }
                apply(p,holder,text.trim()); e.setCancelled(true); p.closeInventory(); Bukkit.getScheduler().runTask(plugin, () -> plugin.gui().openEditor(p,holder.mine));
            }
        }
    }

    @EventHandler public void prepareAnvil(PrepareAnvilEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof AnvilHolder)) return;
        String text = e.getInventory().getRenameText();
        ItemStack left = e.getInventory().getItem(0);
        if (left == null) return;
        ItemStack result = left.clone();
        ItemMeta meta = result.getItemMeta();
        if (text != null && !text.isBlank()) meta.displayName(TextUtil.parse("<white>" + text));
        result.setItemMeta(meta);
        e.setResult(result);
        e.getInventory().setRepairCost(0);
        e.getInventory().setMaximumRepairCost(0);
    }
    private void apply(Player p, AnvilHolder h, String text) {
        Mine m=h.mine;
        try {
            if(h.action.equals("NAME")){ if(text.isBlank()) throw new IllegalArgumentException(); m.setName(text); return; }
            if(h.action.equals("INTERVAL")){ m.setResetIntervalSeconds(Integer.parseInt(text)); return; }
            if(h.action.equals("NOM")){ int[] r=parseRange(text); m.setNomBlocksMin(r[0]); m.setNomBlocksMax(r[1]); return; }
            if(h.action.equals("BLOCK")){ int[] r=parseRange(text); if(h.index>=0 && h.index<m.blocks().size()){m.blocks().get(h.index).setMin(r[0]);m.blocks().get(h.index).setMax(r[1]);} }
        } catch(Exception ex) { p.sendMessage(TextUtil.parse("<red>Неверное значение. Используй число или диапазон <white>10-25<red>.")); }
    }
    private int[] parseRange(String s){ String[] p=s.replace(" ","").split("-"); if(p.length==1){int v=Integer.parseInt(p[0]); return new int[]{v,v};} if(p.length==2){int a=Integer.parseInt(p[0]);int b=Integer.parseInt(p[1]);return new int[]{Math.min(a,b),Math.max(a,b)};} throw new NumberFormatException(); }
}
