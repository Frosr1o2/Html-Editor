package ru.easyboxmines.listener;

import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import ru.easyboxmines.EasyBoXmines;
import ru.easyboxmines.service.SelectionService;
import ru.easyboxmines.util.TextUtil;

public class SelectionListener implements Listener {
    private final EasyBoXmines plugin; private final SelectionService selections;
    public SelectionListener(EasyBoXmines plugin, SelectionService selections){this.plugin=plugin;this.selections=selections;}
    @EventHandler public void interact(PlayerInteractEvent e){
        if(e.getHand()!=EquipmentSlot.HAND || e.getItem()==null) return;
        Material wand = Material.matchMaterial(plugin.getConfig().getString("selection.wand-material", "STICK"));
        if (wand == null) wand = Material.STICK;
        if(e.getItem().getType()!=wand || !e.getPlayer().hasPermission("easyboxmines.admin")) return;
        Player p=e.getPlayer(); var s=selections.get(p);
        if(e.getAction()==Action.LEFT_CLICK_BLOCK){s.set1(e.getClickedBlock().getLocation());p.sendMessage(TextUtil.parse("<#4DFFFF>EasyBoXmines <gray>• <green>Точка 1: <white>"+fmt(e.getClickedBlock().getLocation())));e.setCancelled(true);}
        else if(e.getAction()==Action.RIGHT_CLICK_BLOCK){
            if (p.isSneaking()) { selections.clear(p); p.sendMessage(TextUtil.parse("<#4DFFFF>EasyBoXmines <gray>• <green>Выделение очищено.")); e.setCancelled(true); return; }
            s.set2(e.getClickedBlock().getLocation());p.sendMessage(TextUtil.parse("<#4DFFFF>EasyBoXmines <gray>• <green>Точка 2: <white>"+fmt(e.getClickedBlock().getLocation())));e.setCancelled(true);}
    }
    private String fmt(org.bukkit.Location l){return l.getBlockX()+", "+l.getBlockY()+", "+l.getBlockZ();}
}
