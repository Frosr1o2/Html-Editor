package ru.easyboxmines.service;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import ru.easyboxmines.EasyBoXmines;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Locale;
import java.util.UUID;

/**
 * Best-effort integration with the already installed ServerUtils economy.
 * EasyBoXmines never changes ServerUtils; it only tries to call its public API.
 * If the API is not exposed, the configured Bukkit command is used as fallback.
 */
public final class ServerUtilsCurrency {
    private final EasyBoXmines plugin;

    public ServerUtilsCurrency(EasyBoXmines plugin) {
        this.plugin = plugin;
    }

    public boolean give(Player player, int amount, String type) {
        if (amount <= 0) return true;
        if (tryReflectiveApi(player, amount, type)) return true;

        String command = plugin.getConfig().getString("coins.command", "coins give %player% %amount%");
        if (command == null || command.isBlank()) return false;
        command = command.replace("%player%", player.getName())
                .replace("%uuid%", player.getUniqueId().toString())
                .replace("%amount%", String.valueOf(amount))
                .replace("%type%", type == null ? "blue" : type);
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
    }

    private boolean tryReflectiveApi(Player player, int amount, String type) {
        Plugin serverUtils = Bukkit.getPluginManager().getPlugin("ServerUtils");
        if (serverUtils == null || !serverUtils.isEnabled()) return false;

        Class<?> mainClass = serverUtils.getClass();
        String[] preferred = {
                "addCoins", "giveCoins", "addCoin", "giveCoin",
                "addBalance", "giveBalance", "deposit",
                "addCurrency", "giveCurrency"
        };

        for (String preferredName : preferred) {
            for (Method method : mainClass.getMethods()) {
                if (!Modifier.isPublic(method.getModifiers()) || !method.getName().equalsIgnoreCase(preferredName)) continue;
                if (tryInvoke(method, serverUtils, player, amount, type)) return true;
            }
        }

        for (Method method : mainClass.getMethods()) {
            if (!Modifier.isPublic(method.getModifiers())) continue;
            String n = method.getName().toLowerCase(Locale.ROOT);
            if (!(n.contains("coin") || n.contains("currency") || n.contains("balance") || n.contains("economy"))) continue;
            if (!(n.contains("add") || n.contains("give") || n.contains("deposit") || n.contains("credit"))) continue;
            if (tryInvoke(method, serverUtils, player, amount, type)) return true;
        }
        return false;
    }

    private boolean tryInvoke(Method method, Object target, Player player, int amount, String type) {
        Class<?>[] p = method.getParameterTypes();
        if (p.length < 2 || p.length > 4) return false;

        Object[] args = new Object[p.length];
        boolean[] used = new boolean[p.length];
        int playerIndex = -1;
        int amountIndex = -1;
        int stringIndex = -1;

        for (int i = 0; i < p.length; i++) {
            Class<?> c = p[i];
            if (Player.class.isAssignableFrom(c) || OfflinePlayer.class.isAssignableFrom(c) || UUID.class.isAssignableFrom(c)) {
                playerIndex = i;
                args[i] = c == UUID.class ? player.getUniqueId() : player;
                used[i] = true;
                break;
            }
        }
        if (playerIndex < 0) {
            for (int i = 0; i < p.length; i++) {
                if (p[i] == String.class) { playerIndex = i; break; }
            }
            if (playerIndex >= 0) {
                args[playerIndex] = player.getName();
                used[playerIndex] = true;
            }
        }
        if (playerIndex < 0) return false;

        for (int i = 0; i < p.length; i++) {
            if (used[i]) continue;
            Class<?> c = p[i];
            if (c == int.class || c == Integer.class) { args[i] = amount; amountIndex=i; used[i]=true; break; }
            if (c == long.class || c == Long.class) { args[i] = (long) amount; amountIndex=i; used[i]=true; break; }
            if (c == double.class || c == Double.class) { args[i] = (double) amount; amountIndex=i; used[i]=true; break; }
            if (c == float.class || c == Float.class) { args[i] = (float) amount; amountIndex=i; used[i]=true; break; }
        }
        if (amountIndex < 0) return false;

        for (int i = 0; i < p.length; i++) {
            if (!used[i] && p[i] == String.class) {
                args[i] = type == null ? "blue" : type;
                stringIndex=i;
                used[i]=true;
                break;
            }
        }
        for (int i = 0; i < p.length; i++) if (!used[i]) return false;

        try {
            Object result = method.invoke(target, args);
            return !(result instanceof Boolean b) || b;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // Try a very common alternative argument order when String + numeric parameters exist.
            if (playerIndex >= 0 && stringIndex >= 0) {
                Object tmp = args[playerIndex];
                args[playerIndex] = args[stringIndex];
                args[stringIndex] = tmp;
                try {
                    Object result = method.invoke(target, args);
                    return !(result instanceof Boolean b) || b;
                } catch (ReflectiveOperationException | RuntimeException ignoredAgain) {
                    return false;
                }
            }
            return false;
        }
    }
}
