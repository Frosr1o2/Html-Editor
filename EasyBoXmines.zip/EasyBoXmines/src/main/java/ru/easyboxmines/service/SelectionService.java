package ru.easyboxmines.service;

import ru.easyboxmines.model.Selection;
import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SelectionService {
    private final Map<UUID, Selection> selections = new HashMap<>();
    public Selection get(Player p) { return selections.computeIfAbsent(p.getUniqueId(), k -> new Selection()); }
    public void clear(Player p) { selections.remove(p.getUniqueId()); }
}
