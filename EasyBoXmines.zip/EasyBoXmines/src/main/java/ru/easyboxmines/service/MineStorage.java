package ru.easyboxmines.service;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import ru.easyboxmines.model.*;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class MineStorage {
    private final JavaPlugin plugin;
    private final Map<String, Mine> mines = new LinkedHashMap<>();
    private final File file;
    private FileConfiguration cfg;

    public MineStorage(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "mines.yml");
    }

    public void load() {
        mines.clear();
        if (!file.exists()) {
            try { file.getParentFile().mkdirs(); file.createNewFile(); }
            catch (IOException e) { plugin.getLogger().severe("Не удалось создать mines.yml: " + e.getMessage()); }
        }
        cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = cfg.getConfigurationSection("mines");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            String base = "mines." + id;
            try {
                Pos p1 = readPos(cfg.getString(base + ".pos1"));
                Pos p2 = readPos(cfg.getString(base + ".pos2"));
                if (p1 == null || p2 == null) continue;
                Mine m = new Mine(id, cfg.getString(base + ".name", id), p1, p2);
                m.setResetIntervalSeconds(cfg.getInt(base + ".reset-interval-seconds", plugin.getConfig().getInt("mine-defaults.reset-interval-seconds", 900)));
                m.setMode(MineMode.parse(cfg.getString(base + ".mode"), MineMode.DROPS));
                m.setProtectPlacement(cfg.getBoolean(base + ".protect-placement", true));
                m.setNomBlocksMin(cfg.getInt(base + ".nom-blocks-min", 7));
                m.setNomBlocksMax(cfg.getInt(base + ".nom-blocks-max", 7));
                m.setNomCoinValue(cfg.getInt(base + ".nom-block-coin-value", 9));
                m.setHologramEnabled(cfg.getBoolean(base + ".hologram-enabled", true));
                m.setHologramOffsetY(cfg.getDouble(base + ".hologram-offset-y", 2.5));
                m.setCoinRewardCommand(cfg.getString(base + ".coin-reward-command", ""));
                List<Map<?, ?>> raw = cfg.getMapList(base + ".blocks");
                for (Map<?, ?> row : raw) {
                    MaterialHolder h = MaterialHolder.parse(String.valueOf(row.get("material")));
                    if (h.material == null) continue;
                    int min = intValue(row.get("min"), 1); int max = intValue(row.get("max"), min);
                    m.blocks().add(new BlockRule(h.material, min, max));
                }
                for (String s : cfg.getStringList(base + ".nom-positions")) {
                    Pos np = readPos(s); if (np != null) m.nomPositions().add(np);
                }
                m.setNextResetAtMillis(cfg.getLong(base + ".next-reset-at", 0));
                m.resetBlockCounter();
                m.setRemainingBlocks(cfg.getInt(base + ".remaining-blocks", m.maxBlocks()));
                mines.put(id.toLowerCase(Locale.ROOT), m);
            } catch (Exception ex) {
                plugin.getLogger().warning("Не удалось загрузить шахту " + id + ": " + ex.getMessage());
            }
        }
    }

    private static int intValue(Object o, int def) { if (o instanceof Number n) return n.intValue(); try { return Integer.parseInt(String.valueOf(o)); } catch (Exception e) { return def; } }
    private record MaterialHolder(org.bukkit.Material material) { static MaterialHolder parse(String s) { try { return new MaterialHolder(org.bukkit.Material.valueOf(s.toUpperCase(Locale.ROOT))); } catch (Exception e) { return new MaterialHolder(null); } } }
    private Pos readPos(String s) { if (s == null) return null; String[] p = s.split(","); if (p.length != 4) return null; try { return new Pos(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3])); } catch (Exception e) { return null; } }
    private String writePos(Pos p) { return p.world()+","+p.x()+","+p.y()+","+p.z(); }

    public void save() {
        cfg = new YamlConfiguration();
        for (Mine m : mines.values()) {
            String b = "mines." + m.id();
            cfg.set(b + ".name", m.name());
            cfg.set(b + ".pos1", writePos(m.pos1()));
            cfg.set(b + ".pos2", writePos(m.pos2()));
            cfg.set(b + ".reset-interval-seconds", m.resetIntervalSeconds());
            cfg.set(b + ".mode", m.mode().name());
            cfg.set(b + ".protect-placement", m.protectPlacement());
            cfg.set(b + ".nom-blocks-min", m.nomBlocksMin());
            cfg.set(b + ".nom-blocks-max", m.nomBlocksMax());
            cfg.set(b + ".nom-block-coin-value", m.nomCoinValue());
            cfg.set(b + ".hologram-enabled", m.hologramEnabled());
            cfg.set(b + ".hologram-offset-y", m.hologramOffsetY());
            cfg.set(b + ".coin-reward-command", m.coinRewardCommand());
            List<Map<String, Object>> blocks = new ArrayList<>();
            for (BlockRule r : m.blocks()) blocks.add(Map.of("material", r.material().name(), "min", r.min(), "max", r.max()));
            cfg.set(b + ".blocks", blocks);
            List<String> pos = new ArrayList<>(); for (Pos p : m.nomPositions()) pos.add(writePos(p));
            cfg.set(b + ".nom-positions", pos);
            cfg.set(b + ".next-reset-at", m.nextResetAtMillis());
            cfg.set(b + ".max-blocks", m.maxBlocks());
            cfg.set(b + ".remaining-blocks", m.remainingBlocks());
        }
        try { cfg.save(file); } catch (IOException e) { plugin.getLogger().severe("Не удалось сохранить mines.yml: " + e.getMessage()); }
    }
    public Collection<Mine> all() { return Collections.unmodifiableCollection(mines.values()); }
    public Mine get(String name) { return name == null ? null : mines.get(name.toLowerCase(Locale.ROOT)); }
    public void put(Mine m) { mines.put(m.id().toLowerCase(Locale.ROOT), m); }
    public Mine remove(String name) { return name == null ? null : mines.remove(name.toLowerCase(Locale.ROOT)); }
}
