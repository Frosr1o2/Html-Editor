package ru.easyboxmines.service;

import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.entity.Display;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.TextDisplay;
import org.bukkit.plugin.java.JavaPlugin;
import ru.easyboxmines.model.Mine;
import ru.easyboxmines.util.TextUtil;

import java.util.List;

public class HologramService {
    private final JavaPlugin plugin;
    private final MineStorage storage;
    public HologramService(JavaPlugin plugin, MineStorage storage) { this.plugin = plugin; this.storage = storage; }

    public void spawnOrUpdate(Mine mine) {
        if (!mine.hologramEnabled()) { remove(mine); return; }
        Location loc = mine.center(plugin.getServer());
        if (loc == null || loc.getWorld() == null) return;
        TextDisplay display = mine.hologram();
        if (display == null || display.isDead() || !display.getWorld().equals(loc.getWorld())) {
            if (display != null) display.remove();
            display = (TextDisplay) loc.getWorld().spawnEntity(loc, EntityType.TEXT_DISPLAY);
            display.setBillboard(Display.Billboard.CENTER);
            display.setSeeThrough(false);
            display.setShadowed(true);
            display.setDefaultBackground(false);
            display.setTextOpacity((byte) 255);
            display.setViewRange(48);
            display.setPersistent(false);
            mine.setHologram(display);
        } else {
            display.teleport(loc);
        }

        String time = TextUtil.formatHours(mine.nextResetAtMillis() - System.currentTimeMillis());
        List<String> raw = plugin.getConfig().getStringList("hologram.lines");
        if (raw.isEmpty()) raw = List.of(
                "<#77FFFF>В шахте <white>%blocks%</white> из <white>%maxblocks%</white> блоков</#77FFFF>",
                "<gray>До респавна: <#FFFFFF>%time%</#FFFFFF>"
        );
        String title = plugin.getConfig().getString("hologram.title", "<gradient:#4DFFFF:#198080>◈ %mine%</gradient>")
                .replace("%mine%", mine.name());

        StringBuilder sb = new StringBuilder(title);
        for (String line : raw) {
            sb.append("\n").append(line
                    .replace("%mine%", mine.name())
                    .replace("%blocks%", String.valueOf(mine.remainingBlocks()))
                    .replace("%maxblocks%", String.valueOf(mine.maxBlocks()))
                    .replace("%time%", time)
                    .replace("%nom%", String.valueOf(mine.nomBlocksMin())));
        }
        Component c = TextUtil.parse(sb.toString());
        display.text(c);
    }
    public void remove(Mine mine) { if (mine.hologram() != null) { mine.hologram().remove(); mine.setHologram(null); } }
    public void removeAll() { for (Mine m : storage.all()) remove(m); }
}
