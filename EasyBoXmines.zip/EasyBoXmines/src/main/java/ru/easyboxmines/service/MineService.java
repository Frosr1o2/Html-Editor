package ru.easyboxmines.service;

import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.easyboxmines.EasyBoXmines;
import ru.easyboxmines.model.*;
import ru.easyboxmines.util.TextUtil;

import java.util.*;

public class MineService {
    private final EasyBoXmines plugin;
    private final MineStorage storage;
    private final HologramService holograms;
    private final NamespacedKey nomKey;
    private final Random random = new Random();
    private final ServerUtilsCurrency currency;

    public MineService(EasyBoXmines plugin, MineStorage storage, HologramService holograms) {
        this.plugin = plugin; this.storage = storage; this.holograms = holograms;
        this.currency = new ServerUtilsCurrency(plugin);
        this.nomKey = new NamespacedKey(plugin, "nom_block");
    }

    public void reset(Mine mine, boolean initial) {
        Location c = mine.center(plugin.getServer());
        if (c == null || c.getWorld() == null) return;
        List<Block> volume = new ArrayList<>();
        for (int x=mine.minX(); x<=mine.maxX(); x++) for (int y=mine.minY(); y<=mine.maxY(); y++) for (int z=mine.minZ(); z<=mine.maxZ(); z++) volume.add(c.getWorld().getBlockAt(x,y,z));
        List<Block> eligible = new ArrayList<>(volume);
        Collections.shuffle(eligible, random);
        mine.resetBlockCounter();
        mine.clearNomPositions();
        int nomCount = mine.nomBlocksMin() == mine.nomBlocksMax() ? mine.nomBlocksMin() : randomBetween(mine.nomBlocksMin(), mine.nomBlocksMax());
        int placedNom = 0;
        List<BlockRule> rules = mine.blocks().isEmpty() ? List.of(new BlockRule(Material.STONE, 100, 100)) : mine.blocks();
        int totalWeight = rules.stream().mapToInt(r -> Math.max(1, r.max())).sum();
        // First choose exact counts from each configured rule. Counts are treated as weights/target counts; remaining volume is filled randomly.
        List<Material> planned = new ArrayList<>();
        for (BlockRule r : rules) {
            int amount = r.min() == r.max() ? r.min() : randomBetween(r.min(), r.max());
            amount = Math.max(0, amount);
            for (int i=0;i<amount && planned.size()<eligible.size();i++) planned.add(r.material());
        }
        while (planned.size() < eligible.size()) {
            int roll = random.nextInt(Math.max(1,totalWeight)); int sum=0; Material chosen=rules.get(0).material();
            for (BlockRule r : rules) { sum += Math.max(1,r.max()); if (roll < sum) { chosen=r.material(); break; } }
            planned.add(chosen);
        }
        Collections.shuffle(planned, random);
        for (int i=0; i<eligible.size(); i++) {
            Block b = eligible.get(i);
            Material mat = planned.get(i);
            if (placedNom < nomCount && isSafeForNom(b, mat)) {
                b.setType(Material.WARPED_WART_BLOCK, false);
                mine.nomPositions().add(Pos.of(b.getLocation())); placedNom++;
            } else b.setType(mat, false);
        }
        mine.setNextResetAtMillis(System.currentTimeMillis() + mine.resetIntervalSeconds()*1000L);
        storage.save();
        holograms.spawnOrUpdate(mine);
        c.getWorld().spawnParticle(Particle.END_ROD, c.clone().add(0, -mine.hologramOffsetY() + 1.0, 0), 40, 1.5, 0.5, 1.5, 0.03);
        c.getWorld().playSound(c, Sound.BLOCK_BEACON_ACTIVATE, 0.7f, 1.4f);
        if (!initial) {
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getWorld().getName().equals(mine.pos1().world()) && mine.contains(p.getLocation())) {
                p.sendActionBar(TextUtil.parse("<gradient:#4DFFFF:#198080>◈ Шахта «"+escape(mine.name())+"» обновлена</gradient>"));
            }
        }
    }
    private boolean isSafeForNom(Block b, Material planned) { return b.getType() == Material.AIR || planned.isBlock(); }
    private int randomBetween(int min, int max) { return min >= max ? min : min + random.nextInt(max-min+1); }
    private String escape(String s) { return s.replace("<", ""); }

    public void tick() {
        long now = System.currentTimeMillis();
        for (Mine m : storage.all()) {
            if (m.nextResetAtMillis() <= 0) { m.setNextResetAtMillis(now + m.resetIntervalSeconds()*1000L); storage.save(); }
            else if (m.nextResetAtMillis() <= now) reset(m, false);
            holograms.spawnOrUpdate(m);
        }
    }

    public ItemStack nomCoinBlock(int amount) {
        ItemStack item = new ItemStack(Material.WARPED_WART_BLOCK, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        meta.displayName(TextUtil.itemGradient("Блок Nom Коинов", "#4DFFFF", "#198080", "#4DFFFF"));
        meta.lore(List.of(
                Component.text("▸ ").append(TextUtil.itemGradient("Ценный валютный блок", "#6BE6E6", "#316666", "#77FFFF", "#499999")),
                Component.text("• ").append(TextUtil.itemGradient("Эквивалент: 9 монет", "#94E6E6", "#476666", "#A3FFFF", "#578080"))
        ));
        meta.getPersistentDataContainer().set(nomKey, PersistentDataType.BYTE, (byte)1);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    public void handleBreak(Player player, Block block) {
        for (Mine m : storage.all()) {
            if (!m.contains(block.getLocation())) continue;

            boolean nom = m.isNom(block.getLocation());
            m.decrementBlockCounter();

            if (nom) {
                block.setType(Material.AIR, false);
                if (m.mode() == MineMode.COINS) {
                    boolean paid = currency.give(player, m.nomCoinValue(), "blue");
                    if (!paid) player.sendActionBar(TextUtil.parse("<red>ServerUtils: не удалось выдать Coins</red>"));
                } else {
                    block.getWorld().dropItemNaturally(block.getLocation().add(0.5,0.5,0.5), nomCoinBlock(1));
                }
                m.nomPositions().remove(Pos.of(block.getLocation()));
                storage.save();
                holograms.spawnOrUpdate(m);
                return;
            }

            if (m.mode() == MineMode.COINS) {
                player.sendActionBar(TextUtil.parse("<gradient:#4DFFFF:#198080>EasyBoXmines</gradient> <gray>• <white>"+escape(m.name())+" <dark_gray>• <green>+1 Coin"));
                block.setType(Material.AIR, false);
                boolean paid = currency.give(player, 1, "blue");
                if (!paid) player.sendActionBar(TextUtil.parse("<red>ServerUtils: не удалось выдать Coins</red>"));
            }
            storage.save();
            holograms.spawnOrUpdate(m);
            return;
        }
    }

    public Mine find(Location location) { for (Mine m : storage.all()) if (m.contains(location)) return m; return null; }
    public boolean containsAny(Location location) { return find(location) != null; }
    public boolean overlapsAny(Mine candidate) {
        for (Mine other : storage.all()) {
            if (other.pos1().world() == null || !other.pos1().world().equals(candidate.pos1().world())) continue;
            if (candidate.minX() <= other.maxX() && candidate.maxX() >= other.minX()
                    && candidate.minY() <= other.maxY() && candidate.maxY() >= other.minY()
                    && candidate.minZ() <= other.maxZ() && candidate.maxZ() >= other.minZ()) return true;
        }
        return false;
    }
}
