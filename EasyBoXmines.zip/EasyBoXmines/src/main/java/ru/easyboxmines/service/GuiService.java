package ru.easyboxmines.service;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.easyboxmines.EasyBoXmines;
import ru.easyboxmines.gui.AnvilHolder;
import ru.easyboxmines.gui.MenuHolder;
import ru.easyboxmines.model.BlockRule;
import ru.easyboxmines.model.Mine;
import ru.easyboxmines.model.MineMode;
import ru.easyboxmines.util.TextUtil;

import java.util.ArrayList;
import java.util.List;

public class GuiService {
    private final EasyBoXmines plugin;
    public GuiService(EasyBoXmines plugin) { this.plugin=plugin; }
    private ItemStack item(Material mat, String name, String... lore) {
        ItemStack i = new ItemStack(mat); ItemMeta m=i.getItemMeta(); m.displayName(TextUtil.parse(name));
        if (lore.length>0) m.lore(java.util.Arrays.stream(lore).map(TextUtil::parse).toList()); i.setItemMeta(m); return i;
    }
    public void openEditor(Player p, Mine mine) {
        Inventory inv=Bukkit.createInventory(new MenuHolder("EDITOR", mine),54,TextUtil.parse("<gradient:#4DFFFF:#198080>EasyBoXmines</gradient> <dark_gray>• <gray>"+mine.name()));
        inv.setItem(4,item(Material.NAME_TAG,"<#4DFFFF>✦ Название", "<gray>Текущее: <white>"+mine.name(),"<yellow>Нажми, чтобы изменить"));
        inv.setItem(10,item(Material.CHEST,"<#4DFFFF>▣ Добавить блок", "<gray>Держи нужный блок в основной руке","<yellow>и нажми сюда"));
        inv.setItem(12,item(mine.mode()==MineMode.DROPS?Material.CHEST:Material.GOLD_INGOT,"<#4DFFFF>▣ Режим: <white>"+mine.mode(),"<gray>ЛКМ — переключить","<gray>DROPS = обычный дроп","<gray>COINS = награда Coins"));
        inv.setItem(14,item(Material.CLOCK,"<#4DFFFF>◷ Сброс: <white>"+mine.resetIntervalSeconds()+" сек.","<yellow>Нажми для изменения"));
        inv.setItem(16,item(Material.WARPED_WART_BLOCK,"<#4DFFFF>◈ Nom блоки: <white>"+mine.nomBlocksMin()+"–"+mine.nomBlocksMax(),"<gray>Количество при каждом обновлении","<yellow>Нажми для изменения"));
        inv.setItem(18,item(Material.BOOK,"<#4DFFFF>★ Участок", "<gray>"+mine.pos1().world(), "<gray>От <white>"+mine.minX()+","+mine.minY()+","+mine.minZ(), "<gray>До <white>"+mine.maxX()+","+mine.maxY()+","+mine.maxZ(), "<gray>Блоков: <white>"+mine.maxBlocks()));
        inv.setItem(20,item(mine.hologramEnabled()?Material.END_CRYSTAL:Material.GLASS_BOTTLE, mine.hologramEnabled()?"<#4DFFFF>✦ Голограмма: <green>ВКЛ":"<#4DFFFF>✦ Голограмма: <red>ВЫКЛ", "<gray>Показывает:", "<white>Название шахты", "<white>Оставшиеся блоки", "<white>Время до респавна", "<yellow>Нажми, чтобы переключить"));
        int slot=27; for (int idx=0; idx<mine.blocks().size() && slot<45; idx++,slot++) {
            BlockRule r=mine.blocks().get(idx);
            inv.setItem(slot,item(r.material(),"<#4DFFFF>"+r.material().name(),"<gray>Количество: <white>"+r.min()+"–"+r.max(),"<yellow>ЛКМ: изменить","<red>ПКМ: удалить"));
        }
        inv.setItem(45,item(Material.ARROW,"<gray>Закрыть"));
        inv.setItem(49,item(Material.LIME_WOOL,"<#55FF55>✔ Сохранить", "<gray>Создать/сохранить шахту"));
        inv.setItem(53,item(Material.REDSTONE_BLOCK,"<#FF5555>✖ Удалить", "<gray>Удалить эту шахту"));
        p.openInventory(inv);
    }
    public void openRangeAnvil(Player p, Mine mine, String action, int index, String value) {
        Inventory inv=Bukkit.createInventory(new AnvilHolder(mine,action,index), org.bukkit.event.inventory.InventoryType.ANVIL, TextUtil.parse("<gray>Введи значение"));
        ItemStack paper=item(Material.PAPER,"<white>"+value,"<gray>Можно ввести: 10","<gray>или диапазон: 10-25"); inv.setItem(0,paper); p.openInventory(inv);
    }
}
