package ru.easyboxmines.model;

import org.bukkit.Location;
import java.util.ArrayList;
import java.util.List;

public class Mine {
    private final String id;
    private String name;
    private Pos pos1;
    private Pos pos2;
    private int resetIntervalSeconds;
    private MineMode mode;
    private boolean protectPlacement;
    private int nomBlocksMin;
    private int nomBlocksMax;
    private int nomCoinValue;
    private boolean hologramEnabled;
    private double hologramOffsetY;
    private String coinRewardCommand;
    private final List<BlockRule> blocks = new ArrayList<>();
    private final List<Pos> nomPositions = new ArrayList<>();
    private long nextResetAtMillis;
    private int maxBlocks;
    private int remainingBlocks;
    private org.bukkit.entity.TextDisplay hologram;

    public Mine(String id, String name, Pos pos1, Pos pos2) {
        this.id = id;
        this.name = name;
        this.pos1 = pos1;
        this.pos2 = pos2;
        recalculateMaxBlocks();
    }
    public String id() { return id; }
    public String name() { return name; }
    public void setName(String name) { this.name = name; }
    public Pos pos1() { return pos1; }
    public Pos pos2() { return pos2; }
    public void setPos1(Pos p) { this.pos1 = p; recalculateMaxBlocks(); }
    public void setPos2(Pos p) { this.pos2 = p; recalculateMaxBlocks(); }
    public int resetIntervalSeconds() { return resetIntervalSeconds; }
    public void setResetIntervalSeconds(int v) { this.resetIntervalSeconds = Math.max(10, v); }
    public MineMode mode() { return mode; }
    public void setMode(MineMode mode) { this.mode = mode; }
    public boolean protectPlacement() { return protectPlacement; }
    public void setProtectPlacement(boolean v) { protectPlacement = v; }
    public int nomBlocksMin() { return nomBlocksMin; }
    public int nomBlocksMax() { return nomBlocksMax; }
    public void setNomBlocksMin(int v) { nomBlocksMin = Math.max(0, v); if (nomBlocksMax < nomBlocksMin) nomBlocksMax = nomBlocksMin; }
    public void setNomBlocksMax(int v) { nomBlocksMax = Math.max(nomBlocksMin, v); }
    public int nomCoinValue() { return nomCoinValue; }
    public void setNomCoinValue(int v) { nomCoinValue = Math.max(0, v); }
    public boolean hologramEnabled() { return hologramEnabled; }
    public void setHologramEnabled(boolean v) { hologramEnabled = v; }
    public double hologramOffsetY() { return hologramOffsetY; }
    public void setHologramOffsetY(double v) { hologramOffsetY = v; }
    public String coinRewardCommand() { return coinRewardCommand; }
    public void setCoinRewardCommand(String v) { coinRewardCommand = v == null ? "" : v; }
    public List<BlockRule> blocks() { return blocks; }
    public List<Pos> nomPositions() { return nomPositions; }
    public long nextResetAtMillis() { return nextResetAtMillis; }
    public void setNextResetAtMillis(long v) { nextResetAtMillis = v; }
    public org.bukkit.entity.TextDisplay hologram() { return hologram; }
    public void setHologram(org.bukkit.entity.TextDisplay h) { hologram = h; }

    public int minX() { return Math.min(pos1.x(), pos2.x()); }
    public int maxX() { return Math.max(pos1.x(), pos2.x()); }
    public int minY() { return Math.min(pos1.y(), pos2.y()); }
    public int maxY() { return Math.max(pos1.y(), pos2.y()); }
    public int minZ() { return Math.min(pos1.z(), pos2.z()); }
    public int maxZ() { return Math.max(pos1.z(), pos2.z()); }
    public boolean contains(Location l) {
        if (l == null || l.getWorld() == null || !l.getWorld().getName().equals(pos1.world())) return false;
        return l.getBlockX() >= minX() && l.getBlockX() <= maxX()
                && l.getBlockY() >= minY() && l.getBlockY() <= maxY()
                && l.getBlockZ() >= minZ() && l.getBlockZ() <= maxZ();
    }
    public Location center(org.bukkit.Server server) {
        var w = server.getWorld(pos1.world());
        if (w == null) return null;
        return new Location(w, (minX()+maxX()+1)/2.0, maxY()+hologramOffsetY, (minZ()+maxZ()+1)/2.0);
    }
    public boolean isNom(Location l) { return nomPositions.contains(Pos.of(l)); }
    public void clearNomPositions() { nomPositions.clear(); }

    public int maxBlocks() { return maxBlocks; }
    public int remainingBlocks() { return remainingBlocks; }
    public void recalculateMaxBlocks() {
        if (pos1 == null || pos2 == null) { maxBlocks = 0; remainingBlocks = 0; return; }
        long x = (long) maxX() - minX() + 1L;
        long y = (long) maxY() - minY() + 1L;
        long z = (long) maxZ() - minZ() + 1L;
        long total = Math.max(0L, x * y * z);
        maxBlocks = total > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) total;
        if (remainingBlocks > maxBlocks || remainingBlocks < 0) remainingBlocks = maxBlocks;
    }
    public void resetBlockCounter() { recalculateMaxBlocks(); remainingBlocks = maxBlocks; }
    public void decrementBlockCounter() { if (remainingBlocks > 0) remainingBlocks--; }
    public void setRemainingBlocks(int value) { remainingBlocks = Math.max(0, Math.min(maxBlocks, value)); }
}
