package ru.easyboxmines.model;

import org.bukkit.Material;

public class BlockRule {
    private Material material;
    private int min;
    private int max;

    public BlockRule(Material material, int min, int max) {
        this.material = material;
        this.min = Math.max(0, min);
        this.max = Math.max(this.min, max);
    }

    public Material material() { return material; }
    public int min() { return min; }
    public int max() { return max; }
    public void setMin(int min) { this.min = Math.max(0, min); if (this.max < this.min) this.max = this.min; }
    public void setMax(int max) { this.max = Math.max(this.min, max); }
}
