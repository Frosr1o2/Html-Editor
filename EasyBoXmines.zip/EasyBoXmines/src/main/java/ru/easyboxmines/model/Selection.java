package ru.easyboxmines.model;

import org.bukkit.Location;

public class Selection {
    private Location pos1;
    private Location pos2;
    public Location pos1() { return pos1; }
    public Location pos2() { return pos2; }
    public void set1(Location l) { pos1 = l == null ? null : l.getBlock().getLocation(); }
    public void set2(Location l) { pos2 = l == null ? null : l.getBlock().getLocation(); }
    public boolean complete() { return pos1 != null && pos2 != null && pos1.getWorld() != null && pos2.getWorld() != null && pos1.getWorld().equals(pos2.getWorld()); }
}
