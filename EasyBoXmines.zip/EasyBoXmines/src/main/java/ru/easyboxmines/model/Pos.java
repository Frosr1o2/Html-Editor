package ru.easyboxmines.model;

import org.bukkit.Location;

public record Pos(String world, int x, int y, int z) {
    public static Pos of(Location l) { return new Pos(l.getWorld().getName(), l.getBlockX(), l.getBlockY(), l.getBlockZ()); }
    public Location toLocation(org.bukkit.Server server) {
        var w = server.getWorld(world);
        return w == null ? null : new Location(w, x, y, z);
    }
}
