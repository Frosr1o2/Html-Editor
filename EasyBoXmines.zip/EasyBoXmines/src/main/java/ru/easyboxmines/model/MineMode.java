package ru.easyboxmines.model;

public enum MineMode {
    DROPS,
    COINS;

    public static MineMode parse(String value, MineMode fallback) {
        try { return value == null ? fallback : valueOf(value.toUpperCase()); }
        catch (IllegalArgumentException e) { return fallback; }
    }
}
