package ru.easyboxmines.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;

public final class TextUtil {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private TextUtil() {}
    public static Component parse(String text) { return MM.deserialize(text == null ? "" : text); }
    public static String colorizeLegacy(String text) { return text == null ? "" : text.replace('&', '§'); }
    public static Component itemGradient(String text, String... hex) {
        if (text == null || text.isEmpty()) return Component.empty();
        if (hex.length < 2) return Component.text(text, TextColor.fromHexString(hex.length == 1 ? hex[0] : "#4DFFFF"));
        StringBuilder s = new StringBuilder("<gradient:");
        s.append(String.join(":", hex)).append(">").append(escapeMini(text)).append("</gradient>");
        return MM.deserialize(s.toString());
    }
    private static String escapeMini(String s) { return s.replace("\\", "\\\\").replace("<", "\\<"); }
    public static String formatHours(long millis) {
        long sec = Math.max(0, (millis + 999) / 1000);
        long h = sec / 3600;
        sec %= 3600;
        long m = sec / 60;
        sec %= 60;
        return String.format("%02dч %02dм %02dс", h, m, sec);
    }

    public static String formatDuration(long millis) {
        long sec = Math.max(0, (millis + 999) / 1000);
        long h = sec / 3600; sec %= 3600;
        long m = sec / 60; sec %= 60;
        if (h > 0) return String.format("%02d:%02d:%02d", h, m, sec);
        return String.format("%02d:%02d", m, sec);
    }
}
