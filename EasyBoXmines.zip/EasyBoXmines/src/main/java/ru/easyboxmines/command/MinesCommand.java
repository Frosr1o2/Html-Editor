package ru.easyboxmines.command;

import org.bukkit.command.*;
import org.bukkit.entity.Player;
import ru.easyboxmines.EasyBoXmines;
import ru.easyboxmines.model.Mine;
import ru.easyboxmines.model.MineMode;
import ru.easyboxmines.model.Pos;
import ru.easyboxmines.util.TextUtil;

import java.util.*;

public class MinesCommand implements CommandExecutor, TabCompleter {
    private final EasyBoXmines plugin;
    public MinesCommand(EasyBoXmines plugin){this.plugin=plugin;}
    private boolean admin(CommandSender s){if(s.hasPermission("easyboxmines.admin"))return true;s.sendMessage(TextUtil.parse("<red>Нет прав.</red>"));return false;}
    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a){
        if(a.length==0){help(s);return true;}
        switch(a[0].toLowerCase(Locale.ROOT)){
            case "wand" -> {if(admin(s)&&s instanceof Player p){p.getInventory().addItem(plugin.wand());p.sendMessage(TextUtil.parse("<green>Выдана палка выделения EasyBoXmines."));}}
            case "clear", "unselect" -> {if(admin(s)&&s instanceof Player p){plugin.selections().clear(p);p.sendMessage(TextUtil.parse("<green>✔ Выделение очищено."));}}
            case "pos1","pos2" -> {if(!admin(s)||!(s instanceof Player p))return true;var sel=plugin.selections().get(p);if(!sel.complete()){p.sendMessage(TextUtil.parse("<yellow>Сначала поставь обе точки палкой."));return true;}p.sendMessage(TextUtil.parse("<gray>Точки уже установлены палкой."));}
            case "create" -> {if(!admin(s)||!(s instanceof Player p))return true;if(a.length<2){p.sendMessage(TextUtil.parse("<red>/mines create <название>"));return true;}var sel=plugin.selections().get(p);if(!sel.complete()){p.sendMessage(TextUtil.parse("<red>Нужно поставить первую и вторую точку палкой.</red>"));return true;}String id=safeId(a[1]);if(plugin.storage().get(id)!=null){p.sendMessage(TextUtil.parse("<red>Такая шахта уже существует."));return true;}Mine m=new Mine(id,a[1],Pos.of(sel.pos1()),Pos.of(sel.pos2()));if(plugin.mines().overlapsAny(m)){p.sendMessage(TextUtil.parse("<red>Эта зона пересекается с другой шахтой."));return true;}plugin.applyDefaults(m);plugin.selections().clear(p);plugin.gui().openEditor(p,m);}
            case "edit" -> {if(!admin(s)||!(s instanceof Player p))return true;if(a.length<2){p.sendMessage(TextUtil.parse("<red>/mines edit <название>"));return true;}Mine m=plugin.storage().get(a[1]);if(m==null){p.sendMessage(TextUtil.parse("<red>Шахта не найдена."));return true;}plugin.gui().openEditor(p,m);}
            case "delete" -> {if(!admin(s))return true;if(a.length<2){s.sendMessage(TextUtil.parse("<red>/mines delete <название>"));return true;}Mine m=plugin.storage().remove(a[1]);if(m==null){s.sendMessage(TextUtil.parse("<red>Шахта не найдена."));return true;}plugin.holograms().remove(m);plugin.storage().save();s.sendMessage(TextUtil.parse("<green>Удалена: "+m.name()));}
            case "list" -> {if(!admin(s))return true;StringBuilder out=new StringBuilder("<gradient:#4DFFFF:#198080>EasyBoXmines</gradient> <gray>• шахты:\n");for(Mine m:plugin.storage().all())out.append("<dark_gray>• <white>/mines edit ").append(m.id()).append(" <gray>(").append(m.name()).append(")\n");s.sendMessage(TextUtil.parse(out.toString()));}
            case "hologram", "holo" -> { if(!admin(s))return true; if(a.length<2){s.sendMessage(TextUtil.parse("<red>/mines hologram <название>"));return true;} Mine m=plugin.storage().get(a[1]); if(m==null){s.sendMessage(TextUtil.parse("<red>Шахта не найдена."));return true;} m.setHologramEnabled(true); plugin.holograms().spawnOrUpdate(m); plugin.storage().save(); s.sendMessage(TextUtil.parse("<green>✔ Голограмма шахты «"+m.name()+"» создана/обновлена.")); }
            case "nohologram", "no-holo" -> { if(!admin(s))return true; if(a.length<2){s.sendMessage(TextUtil.parse("<red>/mines nohologram <название>"));return true;} Mine m=plugin.storage().get(a[1]); if(m==null){s.sendMessage(TextUtil.parse("<red>Шахта не найдена."));return true;} m.setHologramEnabled(false); plugin.holograms().remove(m); plugin.storage().save(); s.sendMessage(TextUtil.parse("<yellow>Голограмма шахты «"+m.name()+"» убрана.")); }
            case "info" -> {if(!admin(s))return true;if(a.length<2){s.sendMessage(TextUtil.parse("<red>/mines info <название>"));return true;}Mine m=plugin.storage().get(a[1]);if(m==null){s.sendMessage(TextUtil.parse("<red>Шахта не найдена."));return true;}info(s,m);}
            case "reset" -> {if(!admin(s))return true;if(a.length<2){s.sendMessage(TextUtil.parse("<red>/mines reset <название>"));return true;}Mine m=plugin.storage().get(a[1]);if(m==null){s.sendMessage(TextUtil.parse("<red>Шахта не найдена."));return true;}plugin.mines().reset(m,false);s.sendMessage(TextUtil.parse("<green>Шахта обновлена."));}
            case "resetall" -> {if(!admin(s))return true;for(Mine m:plugin.storage().all())plugin.mines().reset(m,false);s.sendMessage(TextUtil.parse("<green>Все шахты обновлены."));}
            case "reload" -> {if(!admin(s))return true;plugin.reloadConfig();plugin.storage().load();plugin.holograms().removeAll();s.sendMessage(TextUtil.parse("<green>Конфигурация перезагружена."));}
            default -> help(s);
        }return true;
    }
    private void info(CommandSender s,Mine m){s.sendMessage(TextUtil.parse("<gradient:#4DFFFF:#198080>◈ "+m.name()+"</gradient>\n<gray>Режим: <white>"+m.mode()+"\n<gray>Сброс: <white>"+m.resetIntervalSeconds()+" сек.\n<gray>Nom: <white>"+m.nomBlocksMin()+"–"+m.nomBlocksMax()+"\n<gray>Блоков-правил: <white>"+m.blocks().size()));}
    private void help(CommandSender s){s.sendMessage(TextUtil.parse("<gradient:#4DFFFF:#198080>EasyBoXmines</gradient>\n<gray>/mines wand <dark_gray>— палка\n<gray>/mines clear <dark_gray>— убрать текущее выделение\n<gray>/mines create <имя>\n<gray>/mines edit <имя>\n<gray>/mines reset <имя>\n<gray>/mines list\n<gray>/mines info <имя>"));}
    private String safeId(String s){return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]","_");}
    @Override public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args){if(args.length==1)return List.of("wand","clear","create","edit","delete","list","info","reset","hologram","nohologram","resetall","reload").stream().filter(x->x.startsWith(args[0].toLowerCase())).toList();if(args.length==2&&(args[0].equalsIgnoreCase("edit")||args[0].equalsIgnoreCase("delete")||args[0].equalsIgnoreCase("reset")||args[0].equalsIgnoreCase("info")||args[0].equalsIgnoreCase("hologram")||args[0].equalsIgnoreCase("nohologram")))return plugin.storage().all().stream().map(Mine::id).filter(x->x.startsWith(args[1].toLowerCase())).toList();return List.of();}
}
